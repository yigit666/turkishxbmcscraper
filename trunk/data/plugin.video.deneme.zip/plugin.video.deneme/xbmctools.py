# -*- coding: iso8859-9 -*-
# # xbmctr MEDIA CENTER, is an XBMC add on that sorts and displays 
# video content from several websites to the XBMC user.
#
# Copyright (C) 2011, Emin Ayhan Colak
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

# for more info please visit http://xbmctr.com


'''
Edited on 5 April 2012

@author: Dr Ayhan Colak

'''
import urllib,urllib2
import sys,re
import os
import xbmc, xbmcgui, xbmcaddon, xbmcplugin

web='http://xbmctr.com/acces'
addon_id = 'plugin.video.xbmctr'
Addon = xbmcaddon.Addon('plugin.video.xbmctr')
__settings__ = xbmcaddon.Addon(id=addon_id)
addon_path = __settings__.getAddonInfo('path')
downloadFolder = __settings__.getSetting('downloadFolder')
__language__ =__settings__.getLocalizedString

USER_AGENT = "Mozilla/5.0 (X11; Linux x86_64; rv:10.0.1)"
" Gecko/20100101 Firefox/10.0.1"
# Get the system path to where the thumbnail images are stored-
IMAGES_PATH = xbmc.translatePath(os.path.join(Addon.getAddonInfo('path'), 'resources', 'images'))

################################################################################
def name_fix(x):        
        x=x.replace('-',' ')
        return x[0].capitalize() + x[1:]

def name_prepare(videoTitle):
        videoTitle=videoTitle.replace('T�rk�e',"").replace('Turkce',"").replace('Dublaj',"|TR|").replace('Altyaz�l�'," [ ALTYAZILI ] ").replace('izle',"").replace('Full',"").replace('720p',"").replace('HD',"")
        return videoTitle   
        
def get_url(url):
        print ('get_url sonuc',url)
        req = urllib2.Request(url)
        req.add_header('User-Agent', USER_AGENT)
        content = urllib2.urlopen(req)
        data = content.read()
        data=data.replace('\xc3\xa4',"").replace('\xc3\xa8',"'").replace('\xc5\x9f',"s").replace('&#038;',"&").replace('&#8217;',"'").replace('\xc3\xbc',"u").replace('\xc3\x87',"C").replace('\xc4\xb1',"i").replace('&#8211;',"-").replace('\xc3\xa7',"c").replace('\xc3\x96',"O").replace('\xc5\x9e',"S").replace('\xc3\xb6',"o").replace('\xc3\xad',"i").replace('\xc4\x9f',"g").replace('\xc3\x9c',"u").replace('\xc4\xb0',"I").replace('\xe2\x80\x93',"-")
        data=data.replace('\u0131',"i").replace('\xf6',"o").replace('\xd6',"O").replace('\xfc',"u").replace('\xdd',"I").replace('\xfd',"i").replace('\xe7',"c").replace('\xde',"s").replace('\xfe',"s").replace('\xc7',"c").replace('\xf0',"g").replace('&#8211;',"-")
        data=data.replace('\xFD',"i").replace('&#39;&#39;',"\"").replace('&#39;',"\'").replace('\xf6',"o").replace('&amp;',"&").replace('\xd6',"O").replace('\xfc',"u").replace('\xdd',"I").replace('\xfd',"i").replace('\xe7',"c").replace('\xde',"s").replace('\xfe',"s").replace('\xc7',"c").replace('\xf0',"g")
        data=data.replace('\xc5\x9f',"s").replace('&#038;',"&").replace('&#8217;',"'").replace('\xc3\xbc',"u").replace('\xc3\x87',"C").replace('\xc4\xb1',"�").replace('&#8211;',"-").replace('\xc3\xa7',"c").replace('\xc3\x96',"O").replace('\xc5\x9e',"S").replace('\xc3\xb6',"o").replace('\xc4\x9f',"g").replace('\xc4\xb0',"I").replace('\xe2\x80\x93',"-")
        content.close()
        return data
        
def addVideoFolder(FILENAME, videoTitle, method, url, thumbnail, info):
    u = sys.argv[0]+"?fileName="+urllib.quote_plus(FILENAME)+"&videoTitle="+urllib.quote_plus(videoTitle)+"&method="+urllib.quote_plus(method)+"&url="+urllib.quote_plus(url)+"&thumbnail="+urllib.quote_plus(thumbnail)
    liz = xbmcgui.ListItem(videoTitle, iconImage="DefaultFolder.png", thumbnailImage=thumbnail)
    liz.setInfo(type="Video", infoLabels=info)
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=True)
    

def addVideoLink(linkTitle, url, thumbnail=""):
    print linkTitle, url, thumbnail
    liz = xbmcgui.ListItem(linkTitle, iconImage="DefaultVideo.png", thumbnailImage=thumbnail)
    liz.setInfo(type="Video", infoLabels={"Title":linkTitle})
    liz.setProperty("IsPlayable", "true")
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=False)
    
def addFolder(FILENAME, name, method, url="", thumbnail=""):
    u = sys.argv[0]+"?fileName="+urllib.quote_plus(FILENAME)+"&method="+urllib.quote_plus(method)+"&url="+urllib.quote_plus(url)
    if thumbnail != "":
        thumbnail = os.path.join(IMAGES_PATH, thumbnail+".png")
    liz = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=thumbnail)
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=True)


def openfile(filename):
     fh = open(filename, 'r')
     contents=fh.read()
     fh.close()
     return contents

def save(filename,contents):  
     fh = open(filename, 'w')
     fh.write(contents)  
     fh.close()

def appendfile(filename,contents):  
     fh = open(filename, 'a')
     fh.write(contents)  
     fh.close()

def stage(videoTitle,links):
        nameCount=0
        subfolder=os.path.join(downloadFolder,str(videoTitle))
        os.makedirs(subfolder)
        for videoLink in links:
            name='Part'
            nameCount=nameCount+1
            name= name+' '+str(nameCount)
            filename = (videoTitle+' '+name+'.mp4')
            filepath = xbmc.translatePath(os.path.join(subfolder,filename))
            def download(url, dest):
                    #dialog = xbmcgui.DialogProgress()
                    #dialog.create('Downloading Movie','From Source', filename)
                    urllib.urlretrieve(url, dest, lambda nb, bs, fs, url = url: _pbhook(nb, bs, fs, url,''))
            def _pbhook(numblocks, blocksize, filesize, url = None,dialog = None):
                    try:
                        
                        percent = min((numblocks * blocksize * 100) / filesize, 100)
                        #dialog.update(percent)
                    except:
                        percent = 100
                        #dialog.update(percent)
                    #if dialog.iscanceled():
                                    #dialog.close()
            download(videoLink, filepath)
            iscanceled = True
            xbmc.executebuiltin('Notification("Media Center","part Complete")')
               
def Download_tool():        
        if downloadFolder is '':
                d = xbmcgui.Dialog()
                d.ok('Download Error','You have not set the download folder.\n Please set the addon settings and try again.','','')
                __settings__.openSettings(sys.argv[ 0 ])
        else:
                if not os.path.exists(downloadFolder):
                        print 'Download Folder Doesnt exist. Trying to create it.'
                        os.makedirs(downloadFolder)
                        
def Download_list(videoTitle,url,genre,section):
        
########prepare video link both page system and xml system'''
        Download_tool()
        links = url.split(':;')
        del links [-1]
        if section=='page':
                for pageLink in links:
                    link=get_url(pageLink)
                    links=re.compile('<embed src=\'.*?file=(.*?)&a').findall(link)
                    stage(videoTitle,links)        
        if section=='xml':
                stage(videoTitle,links)
                
        xbmc.executebuiltin('Notification("Media Center","Download Complete")')

def Download_single(videoTitle,url):
        Download_tool()
        subfolder=os.path.join(downloadFolder,str(videoTitle))
        os.makedirs(subfolder)
        filename = (videoTitle)
        filepath = xbmc.translatePath(os.path.join(subfolder,filename))
        def download(url, dest):
                    #dialog = xbmcgui.DialogProgress()
                    #dialog.create('Downloading Movie','From Source', filename)
                    urllib.urlretrieve(url, dest, lambda nb, bs, fs, url = url: _pbhook(nb, bs, fs, url,''))
        def _pbhook(numblocks, blocksize, filesize, url = None,dialog = None):
                    try:
                        
                        percent = min((numblocks * blocksize * 100) / filesize, 100)
                        #dialog.update(percent)
                    except:
                        percent = 100
                        #dialog.update(percent)
                    #if dialog.iscanceled():
                                    #dialog.close()
        download(url, filepath)
        iscanceled = True
        xbmc.executebuiltin('Notification("Media Center","part Complete")')
