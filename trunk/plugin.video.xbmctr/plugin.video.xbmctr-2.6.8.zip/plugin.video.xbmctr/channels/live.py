# xbmctr MEDIA CENTER, is an XBMC add on that sorts and displays 
# video content from several websites to the XBMC user.
#
# Copyright (C) 2011, Emin Ayhan Colak
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

# for more info please visit http://xbmctr.com
import base64
import cookielib,sys
import urllib2,urllib,re,os
import xbmcplugin,xbmcgui,xbmc,xbmcaddon 
import scraper, xbmctools
from BeautifulSoup import BeautifulStoneSoup, BeautifulSoup, BeautifulSOAP
try:
    import json
except:
    import simplejson as json
# -*- coding: iso-8859-9 -*-
Addon = xbmcaddon.Addon('plugin.video.xbmcTR')
profile = xbmc.translatePath(Addon.getAddonInfo('profile'))
addonsettings = xbmcaddon.Addon(id='plugin.video.xbmcTR')


FILENAME = "live"
web='http://xbmctr.com/acces'
__language__ = addonsettings.getLocalizedString
home = addonsettings.getAddonInfo('path')
icon = xbmc.translatePath( os.path.join( home, 'icon.png' ) )
fanart = xbmc.translatePath( os.path.join( home, 'fanart.jpg' ) )

   




def main():
    link=xbmctools.get_url(web)
    first=re.compile('&(.*?)&').findall(link)
    match=re.compile('<a>(.*?)</a>(.*?)<p>').findall(base64.b64decode(first[0]))
    for url,videoTitle in match:
        xbmctools.addFolder(FILENAME,videoTitle, "getData(url)",url,'')
        


def getSoup(url):
        print 'getSoup(): '+url
        if url.startswith('http://'):
            try:
                req = urllib2.Request(url)
                response = urllib2.urlopen(req)
                data = response.read()
                response.close()
            except urllib2.URLError, e:
                # errorStr = str(e.read())
                if hasattr(e, 'code'):
                    print 'We failed with error code - %s.' % e.code
                    xbmc.executebuiltin("XBMC.Notification(error code - "+str(e.code)+",10000,"+icon+")")
                elif hasattr(e, 'reason'):
                    print 'We failed to reach a server.'
                    print 'Reason: ', e.reason
                    xbmc.executebuiltin("XBMC.Notification(failed to reach a server. - "+str(e.reason)+",10000,"+icon+")")
        else:
            data = open(url, 'r').read()
        soup = BeautifulSOAP(data, convertEntities=BeautifulStoneSoup.XML_ENTITIES)
        return soup


def getData(url):
        soup = getSoup(url)
        getItems(soup('item'))


def getSubChannelItems(name,url,fanart):
        soup = getSoup(url)
        channel_list = soup.find('subchannel', attrs={'name' : name})
        items = channel_list('subitem')
        getItems(items,fanart)


def getItems(items):
        for item in items:
            try:
                name = item('title')[0].string
            except:
                print '-----Name Error----'
                name = ''
            try:
                if item('epg'):
                    if item('epg')[0].string > 1:
                        name += getepg(item('epg')[0].string)
                else:
                    pass
            except:
                print '----- EPG Error ----'

            try:
                if addonsettings.getSetting('mirror_link') == "true":
                    try:
                        url = item('link')[1].string	
                    except:
                        url = item('link')[0].string
                if addonsettings.getSetting('mirror_link_low') == "true":
                    try:
                        url = item('link')[2].string	
                    except:
                        try:
                            url = item('link')[1].string
                        except:
                            url = item('link')[0].string
                else:
                    url = item('link')[0].string
            except:
                print '---- URL Error Passing ----'+name
                pass

            try:
                thumbnail = item('thumbnail')[0].string
                if thumbnail == None:
                    raise
            except:
                thumbnail = ''
            try:    
                if not item('fanart'):
                    if addonsettings.getSetting('use_thumb') == "true":
                        fanArt = thumbnail
                    else:
                        fanArt = fanart
                else:
                    fanArt = item('fanart')[0].string
                if fanArt == None:
                    raise
            except:
                fanArt = fanart
            try:
                desc = item('info')[0].string
            except:
                desc = ''

            try:
                genre = item('genre')[0].string
            except:
                genre = ''

            try:
                date = item('date')[0].string
            except:
                date = ''
            try:
                xbmctools.addVideoLink(name.encode('utf-8', 'ignore'),url,thumbnail)
            except:
                print 'There was a problem adding link - '+name.encode('utf-8', 'ignore')
                



