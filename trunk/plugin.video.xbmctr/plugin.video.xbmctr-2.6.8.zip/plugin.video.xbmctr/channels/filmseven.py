import urllib,urllib2,re,sys
import xbmcplugin,xbmcgui,xbmcaddon,xbmc
import scraper,xbmctools

# -*- coding: iso-8859-9 -*-
Addon = xbmcaddon.Addon('plugin.video.xbmcTR')
__settings__ = xbmcaddon.Addon(id='plugin.video.xbmcTR')
__language__ = __settings__.getLocalizedString


FILENAME = "filmseven"

 
            
def main():
        xbmctools.addFolder(FILENAME,__language__(30011), "search()", '')
        xbmctools.addFolder(FILENAME,__language__(30016), "RECENT(url)", "http://www.filmsevenler.net/")
        xbmctools.addFolder(FILENAME,__language__(30015), "Categories(url)", "http://www.filmsevenler.net/")         

def search():
        keyboard = xbmc.Keyboard("", 'Search', False)
        keyboard.doModal()
        if keyboard.isConfirmed():
            query = keyboard.getText()
            #print query
            url = ('http://www.filmsevenler.net/?s='+ query)
            new(url)
        
                        
def RECENT(url):
        print url
        link=xbmctools.get_url(url)       
        match=re.compile('<a\nhref="(.*?)" title=".*?" ><img\nsrc="(.*?)" alt="(.*?)" class=".*?"/>').findall(link)
        for Url,thumbnail,videoTitle in match:
                xbmctools.addFolder("scraper",videoTitle+' >> TOP LIST',"prepare_list(videoTitle,Url)",Url,thumbnail)
        new(url)
def new(url):
        link=xbmctools.get_url(url)
        match2=re.compile('<a\nhref="(.*?)" title=".*?"><img\nsrc="(.*?)" alt="(.*?)" class="thumbnail"').findall(link)
        for url,thumbnail,videoTitle in match2:
                xbmctools.addFolder("scraper",videoTitle,"prepare_list(videoTitle,url)",url,thumbnail)
        page=re.compile(r'page-numbers current\'>.*?</span> <a\nclass=\'page-numbers\' href=\'(.*?)\'>.*?</a>').findall(link)
        for url in page:
                xbmctools.addFolder(FILENAME,__language__(30006)+' >> ',"new(url)",url,'')
        
        
        
def Categories(url):
        link=xbmctools.get_url(url)
        match=re.compile('<li\nclass=".*?"><a\nhref="(.*?)" title=".*?">(.*?)</a></li>').findall(link)
        for url,videoTitle in match:
            xbmctools.addFolder(FILENAME,videoTitle,"Session(url)",url,'')
        
def Session(url):
                link=xbmctools.get_url(url)
                match=re.compile('<a\nhref="(.*?)" title=".*?"><img\nsrc="(.*?)" alt="(.*?)" class="thumbnail"').findall(link)
                for url,thumbnail,videoTitle in match:
                        xbmctools.addFolder("scraper",videoTitle, "prepare_list(videoTitle,url)",url,thumbnail)
                
      


def MAINMENU(url):
         xbmctools.addFolder(FILENAME,'<<<'+__language__(30002),"main()",'http://www.filmsevenler.net/','')
        

    
