﻿import urllib,urllib2,re,sys
# xbmctr MEDIA CENTER, is an XBMC add on that sorts and displays 
# video content from several websites to the XBMC user.
#
# Copyright (C) 2011, Emin Ayhan Colak
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

# for more info please visit http://xbmctr.com

import xbmcplugin,xbmcgui,xbmcaddon,xbmc
import scraper, xbmctools

# -*- coding: iso-8859-9 -*-
Addon = xbmcaddon.Addon('plugin.video.xbmctr')
__settings__ = xbmcaddon.Addon(id='plugin.video.xbmctr')
__language__ = __settings__.getLocalizedString
xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_UNSORTED)
xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_LABEL) 

FILENAME = "yabancidizi"
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)

            
def main():
        url='http://yabancidiziizle.com/'
        xbmctools.addFolder(FILENAME,__language__(30011), "search()", '')
        xbmctools.addFolder(FILENAME,__language__(30016), "RECENT(url)", "http://yabancidiziizle.com/")
        link=xbmctools.get_url(url)
        match=re.compile('<li><a href="(.*?)" title=".*?">(.*?)</a></li><li>').findall(link)	
        #kategori-1
        del match[0]
        for url,videoTitle in match:
                xbmctools.addFolder(FILENAME,videoTitle,"Session(url)",'http://yabancidiziizle.com'+url,'')
        #kategori-2
        second=re.compile('<li><a href="(.*?)" title=".*?" class="iki">(.*?)</a></li><li>').findall(link)
        del second[0]
        for url,videoTitle in second:
                xbmctools.addFolder(FILENAME,videoTitle,"Session(url)",'http://yabancidiziizle.com'+url,'')
        #sayfalama
        page=re.compile('class="aktif">.*?</a><a href="(.*?)">(.*?)</a>').findall(link)
        for url,videoTitle in page:
                xbmctools.addFolder(FILENAME,videoTitle,"main(url)",'http://yabancidiziizle.com'+url,'')
         

def search():
        keyboard = xbmc.Keyboard("", 'Search', False)
        keyboard.doModal()
        if keyboard.isConfirmed():
            query = keyboard.getText()
            url = ('http://yabancidiziizle.com/ara.php?q='+ query)
            RECENT(url)
                        
def RECENT(url):
        MAINMENU(url)

        link=xbmctools.get_url(url)

        #next page        
        page=re.compile('class="aktif">.*?</a><a href="(.*?)">(.*?)</a>').findall(link)
        print page
        for url,videoTitle in page:
                xbmctools.addFolder(FILENAME,__language__(30006)+' >> '+videoTitle,"RECENT(url)",'http://diziport.com/'+url,'')
        

        match=re.compile('<a href="(.*?)" title=".*?" class="img"><img src="(.*?)" alt="(.*?)"').findall(link)
        for url,thumbnail,videoTitle in match:
                xbmctools.addFolder(FILENAME,videoTitle,"choose(videoTitle,'http://yabancidiziizle.com'+url)",url,thumbnail)
               
        
def Session(url):
                link=xbmctools.get_url(url)
                match=re.compile('<a href="(.*?)" title=".*?" class="img"><img src="(.*?)" alt="(.*?)"').findall(link)
                for url,thumbnail,videoTitle in match:
                                xbmctools.addFolder(FILENAME,videoTitle, "Episodes(url)",url)
                
def Episodes(url):
        link=xbmctools.get_url(url)
        match=re.compile('<a href="(.*?)" title=".*?" class="img"><img src="(.*?)" alt="(.*?)"').findall(link)
        for url,thumbnail,videoTitle in match:
            xbmctools.addFolder(FILENAME,videoTitle,"choose(videoTitle,'http://yabancidiziizle.com'+url)",url)



def choose(videoTitle,url):
        playList.clear()
        link=xbmctools.get_url(url)
        yabanci_1=re.compile(r'{ file: "(.*?)" }').findall(link)#sayfada face linkleri
        yabanci_720p=re.compile('<li><a href="(.*?)" title=".*?">720p</a></li>').findall(link)
        yabanci_tek=re.compile('<li><a href="(.*?)" title=".*?">TEK PART</a></li>').findall(link)
        print len(yabanci_1),len(yabanci_720p),len(yabanci_tek)
        dialog = xbmcgui.Dialog()
        if ( len(yabanci_1)>= 1 ) : a="SD - DUSUK  > 160 kb/s"
        else:
                 a= 'No Video !!'
        if ( len(yabanci_1)>= 1 ) : b="HQ - ORTA   > 450 kb/s"
        else:
                b= 'No Video !!'
        if (len(yabanci_720p))>= 1: c="HD - 720P   > 1100 kb/s"
        else:
                c= 'No Video !!'
        if (len(yabanci_tek))>= 1: d= "  > ALTERNATİF - TEK LINK"       
        else:
                d= 'No Video !!'
       
        ret = dialog.select(__language__(30008),[a,b,c,d])
        if ret == 0:
                        x=1
                        for i in range(3,6):
                                tup=tuple(yabanci_1)
                                xbmctools.addVideoLink(videoTitle+' Part '+str(x),tup[i],'')
                                playList.add(tup[i])
                                x+=1
                

        if ret == 1:
                        for i in range(3):
                                tup=tuple(yabanci_1)
                                xbmctools.addVideoLink(videoTitle+' Part '+str(i),tup[i],'')
                                playList.add(tup[i])
               
        if ret == 2:
                
                        for url in yabanci_720p:
                                link=xbmctools.get_url('http://yabancidiziizle.com'+url)
                                match=re.compile('{ file: "(.*?)" }').findall(link)#sayfada face linkleri
                                for i in range(3):
                                        tup=tuple(match)
                                        xbmctools.addVideoLink(videoTitle+' Part '+str(i),tup[i],'')
                                        playList.add(tup[i])
                
        if ret == 3:
               
                        url='http://yabancidiziizle.com'+str(yabanci_tek[0])
                        link=xbmctools.get_url(url)
                        streamer=re.compile('streamer: "(.*?)"').findall(link)#sayfada streamer linki
                        url =streamer[0]+'&&file=123.flv&start=0'
                        xbmctools.addVideoLink(videoTitle,url,'')
                        playList.add(url)
                
        xbmcPlayer.play(playList) 
                
def MAINMENU(url):
         xbmctools.addFolder(FILENAME,'<<<'+__language__(30002),"main()",'http://yabancidiziizle.com/','')

         

