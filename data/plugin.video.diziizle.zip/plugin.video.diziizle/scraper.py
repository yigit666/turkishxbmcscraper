# -*- coding: iso-8859-9 -*-
# xbmctr MEDIA CENTER, is an XBMC add on that sorts and displays 
# video content from several websites to the XBMC user.
#
# Copyright (C) 2011, Dr Ayhan Colak
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

# for more info please visit http://xbmctr.com

'''
Author: drascom
Date: 13/04/2012
'''

# -*- coding: iso-8859-9 -*-
import urllib, urllib2, re, sys, cookielib
import xbmc, xbmcaddon, xbmcgui,xbmcplugin
import xbmctools
import mechanize


    
__settings__ = xbmcaddon.Addon(id='plugin.video.xbmctr')
__language__ = __settings__.getLocalizedString


FILENAME = "scraper"

#Used to allow the user to select quality on youtube videos
addonSettings = xbmcaddon.Addon(id='plugin.video.xbmctr')




'''Constants'''
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
vk=[]
value=[]




'''
listing,pagination function
for multipage web site
'''

def unique(l):
    s = set(); n = 0
    for x in l:
        if x not in s: s.add(x); l[n] = x; n += 1
    del l[n:]

    
def fullfilm_gizli_player(url):
##        print 'GIZLI PLaYER url ',url
        link=xbmctools.get_url(url)
        link=link.replace('%3A',":").replace('%3F',"?").replace('%3D',"=")
        match=re.compile('v=(.*?)&').findall(link)
##        print 'GIZLI PLaYER',match
        url=match[0]
        return url

def prepare_page_list(Url,match):
##        print 'Paging started'
        urlList=''
        for pageUrl in match:
                #web page list function
                urlList=urlList+pageUrl #add page to list
                urlList=urlList+':;'    #add seperator
                total=Url+':;'+urlList  #add first url
                match = total.split(':;') #split links
                del match [-1]            #delete first seperator
                #print match
        info='Film '+str(len(match)-1)+' part.'
        print info
        return match


def prepare_face_links(videoTitle,match):
        i=0
        for pageLink in match:
                link=xbmctools.get_url(pageLink)
                match=re.compile('<embed src=\'.*?file=(.*?)&a').findall(link)
                for videoLink in match:
                        i+=1
                        xbmctools.addVideoLink(videoTitle+' Part '+str(i),videoLink,'')
                        playList.add(videoLink)
def youtube_single(code):
        code='plugin://plugin.video.youtube/?action=play_video&videoid=' + str(code)
        return code

def Divx(videoTitle,code):
        xbmc.executebuiltin('Notification("Media Center",DIVXSTAGE Deneniyor.)')
        url='http://embed.divxstage.eu/embed.php'+code
        link=xbmctools.get_url(url)
        match=re.compile('domain="http://www.divxstage.eu";\n\t\t\tflashvars.file="(.*?)";\n\t\t\tflashvars\.filekey="(.*?)"').findall(link)
        if not match:
            xbmc.executebuiltin('Notification("Sitede HATA ",Server Linki yok.)')
        for dosya,key in match:
            url ='http://www.divxstage.eu/api/player.api.php?file='+dosya+'&key='+key
            link=xbmctools.get_url(url)
            match=re.compile('url=(.*?)&').findall(link)
            if not match:
                xbmc.executebuiltin('Notification("Serverda HATA ",Video Linki yok.)')
            for url in match:
                    if url.endswith('flv'):
                            xbmctools.addVideoLink(videoTitle,str(url),'')
                            playList.add(url)
                    else:
                        pass
def Mov(videoTitle,code):
        xbmc.executebuiltin('Notification("Media Center",MOVSHARE Deneniyor.)')
        url='http://embed.movshare.net/embed.php'+code
        link=xbmctools.get_url(url)
        match=re.compile('domain="http://www.movshare.net";\n\t\t\tflashvars.file="(.*?)";\n\t\t\tflashvars\.filekey="(.*?)"').findall(link)
        if not match:
            xbmc.executebuiltin('Notification("Sitede HATA ",Server Linki yok.)')
        for dosya,key in match:
            url ='http://www.movshare.net/api/player.api.php?file='+dosya+'&key='+key
            link=xbmctools.get_url(url)
            match=re.compile('url=(.*?)&').findall(link)
            if not match:
                xbmc.executebuiltin('Notification("Serverda HATA ",Video Linki yok.)')
            for url in match:
                    if url.endswith('flv'):
                            xbmctools.addVideoLink((videoTitle+'Movshare'),str(url),'')
                            playList.add(url)
                    else:
                        pass                

def Dailymotion(code):
        value=[]
        count=[]
        url="http://www.dailymotion.com/embed/video/"+code
        link=xbmctools.get_url(url)
        link = urllib.unquote(link).decode('utf8').replace('\\/', '/')
        dm_high = re.compile('"stream_h264_url":"(.+?)"').findall(link)
        dm_low = re.compile('"stream_h264_ld_url":"(.+?)"').findall(link)
        if dm_high:
                count.append('Dailymotion 360kb/s HD')
        if dm_low:
                count.append('Dailymotion 180kb/s SD ')
        else:
                pass
        dialog = xbmcgui.Dialog()
        ret = dialog.select(__language__(30008),count)
        if ret == 0:
                
                value.append(('Dailymotion 384 p',dm_high[0]))
        if ret == 1:

                value.append(('Dailymotion 240 p',dm_low[0]))
        
        return value

def first_vk(vk_list):
        value=[]
        count=[]
        fixed=''
        gecis=0
        resolutions = ["240", "360", "480", "720", "1080"]
        del vk_list[0]
        print 'VK LIST',vk_list
        for url in vk_list:
                try:
                        print 'VK URL IN TEST:',url
                        link=xbmctools.get_url(url)
                        host=re.compile("host=(.*?)&").findall(link)
                        uid=re.compile("uid=(.*?)&").findall(link)
                        vtag=re.compile("vtag=(.*?)&").findall(link)
                        hd = re.compile("hd_def=(.*?)&").findall(link)
                        flv = re.compile("no_flv=(.*?)&").findall(link)
                        #http://cs514110.userapi.com/u175995076/video/ac8f196d08.xxx.mp4
                        start_url=host[0]+'u'+uid[0]+'/videos/' + vtag[0]
                        x=(int(hd[0])+1)
                        if hd >0 or flv == 1:
                                for i in range (x):
                                        i=resolutions[i]+' p'
                                        count.append(i) 
                                if gecis==0:
                                        dialog = xbmcgui.Dialog()
                                        ret = dialog.select(__language__(30008),count)
                                        for i in range (x):
                                                if ret == i:
                                                        url=start_url+'.'+str(resolutions[i])+'.mp4'
                                                        fixed=str(resolutions[i])
                                                        gecis+=1
                                                        
                                                else:
                                                        'VK SECIM YOK'
                                else:
                                        url=start_url+'.'+fixed+'.mp4'
                                        print ('SECIM :'+fixed)
                                        gecis+=1
                                value.append(('VK ',url))
                        else:
                                print 'HD FLV YANLIS'
                except:
                        print 'LINK TARAMA FAILED'
                        pass
        return value



def xml_scanner(videoTitle,match):
        playList.clear()
        xmlScan=xbmctools.get_url(match)
        face_1=re.compile('http://dizihd.com/dizihdd.php(.+?)"').findall(xmlScan)#xml ici face link
        youtube_1=re.compile('v=(.*?)"').findall(xmlScan)#xml i�i youtube link
        dizimag=re.compile('url="(.*?)"').findall(xmlScan) #xml ici dizimag                               
        music=re.compile('<file>(.*?)</file>').findall(xmlScan)
        try:
                if len(youtube_1)> 0  :
##                        print '[youtube]'
                        for i in youtube_1:
                                Url='plugin://plugin.video.youtube/?action=play_video&videoid='+str(youtube_1[0])
                                xbmctools.addVideoLink('Reklam',Url,'')
                x=1
                if len(face_1)> 0  :
                        print '[face]'
                        for i in face_1:
                                Url='http://dizihd.com/dizihdd.php'+str(i)
                                xbmctools.addVideoLink(videoTitle+' Part '+str(x),Url,'')
                                playList.add(Url)
                                x+=1
                if len(dizimag)> 0  :
                        print '[dizimag]'
                        for i in dizimag:
                                xbmctools.addVideoLink(videoTitle+' Part '+str(x),i,'')
                                playList.add(i)
                                x+=1
                if len(music)> 0  :
                        print '[music]'
                        for i in music:
                                xbmctools.addVideoLink(videoTitle+' Part '+str(x),i,'')
                                playList.add(i)
                                x+=1
                                
                                
        except:
                
                xbmcPlayer.play(playList)
        xbmcplugin.endOfDirectory(handle=int(sys.argv[1]), succeeded=True)



def prepare_list(videoTitle,Url):
        value=[]
        print '************ scraper intro ***********',(videoTitle,Url)
        mode=''
        if xbmcPlayer.isPlaying():
                xbmcPlayer.stop()
        playList.clear()

                        
        link=xbmctools.get_url(Url)

        #--------------  fullfilm tab okuma bolumu baslar------------------------
        name=[]
        tab=re.compile(u'posTabsShowLinks\(\'(.*?)\'').findall(link)
        print 'tabs:',tab
        for isim in tab:
                name.append(isim)
        #--------------  fullfilm tab okuma bolumu biter------------------------
                
        if len(tab) > 2:
                mode = 1 #multi page
                xbmc.executebuiltin('Notification("Full Film","Partli Sistem")')
        else:
                mode = 2 #single page
                xbmc.executebuiltin('Notification("Full Film ","Tek Link / Oto Part")')


        #--------------  sayfa tarama bolumu baslar------------------------
        divxstage=re.compile('src=.*?divxstage\.eu/embed\.php(.*?)\&').findall(link) 
        movshare=re.compile('src=.*?movshare\.net/embed\.php(.*?)\&').findall(link)        
        face_1=re.compile('xmlAddress = \'(.+?)\'').findall(link)
        vk_1=re.compile('http://vk.com/(.*?)"').findall(link)
        vk_2=re.compile('video_host = \'(.*?)/\';\nvar video_uid = \'(.*?)\';\nvar video_vtag = \'(.*?)\'').findall(link)
        streamer=re.compile('streamer: "(.*?)"').findall(link)#sayfada streamer linki
        full_1=re.compile('<embed src=\'.*?file=(.*?)&a').findall(link)#check direct link
        full_2=re.compile('<iframe src="(.*?)" height="450" width="708" frameborder="0" scrolling="no"></iframe>').findall(link)#check youtube
        full_3=re.compile('\/twtif.php\?id=(.*?)"').findall(link)
        lowres=re.compile('dusuk="(.*?)"').findall(link)
        highres=re.compile('yuksek="(.*?)"').findall(link)
        sinema_1=re.compile('name=".*?file=(.*?)&image=.*?"').findall(link)
        diziizle_wm=re.compile('player=1&link=(.*?).wmv\'').findall(link)
        diziizle_mov=re.compile('movshare\.net/.*?/(.*?)/').findall(link)
        diziizle_dm=re.compile('http://www.dailymotion.com\/embed\/video\/(.*?)\?.*?</iframe>').findall(link)
        streamer=re.compile(u'ticket=(.*?)"').findall(link)
        yabanci_dizi=re.compile(r'{ file: "(.*?)" }').findall(link)#sayfada face linkleri
        youtube_1=re.compile('youtube.com/.*?/(.*?)"\?').findall(link)
        print '[youtube1]'+str(youtube_1)
        if not youtube_1:
                youtube_1=re.compile('"http://www.youtube.com/embed/(.*?)"').findall(link)
                print '[youtube2]'+str(youtube_1)
                if not youtube_1:
                        youtube_1=re.compile('youtube.com/.*?/(.*?)&.*?"').findall(link)
                        print '[youtube3]'+str(youtube_1)
                        link=link.replace('%3A',":").replace('%3F',"?").replace('%3D',"=")
                        match=re.compile('v=(.*?)&').findall(link)
                        print 'Gizli PLAYER',match
                        
        music=re.compile('http://player.iyimix.com/config/(.*?).xml').findall(link)
        filmseven = re.compile('file=(.*?)&logo').findall(link)
        result = ' diziizle_dm= '+str(len(diziizle_dm)),' diziizle_mv= '+str(len(diziizle_mov)),' diziizle_wm= '+str(len(diziizle_wm)),' yabanci_dizi= '+str(len(yabanci_dizi)),' movshare= '+str(len(movshare)),' divxstage= '+str(len(divxstage)),' face_1= '+str(len(face_1)),' vk 1 = '+str(len(vk_1)),' vk 2 = '+str(len(vk_2)),' streamer='+str(len(streamer)),' full 1 = '+str(len(full_1)),' full 2 = '+str(len(full_2)),' full 3 = '+str(len(full_3)),len(lowres),len(highres),len(sinema_1),' youtube_1 = '+str(len(youtube_1)),' music = '+str(len(music)),' streamer = '+str(len(streamer))
        
        print result,Url,'mode '+str(mode)

        


        x=0 #sayac
        for code in diziizle_dm:
                print 'dm code:',code
                Result=Dailymotion(code)
                for name,url in Result:
                        value.append((videoTitle,url,''))

        for code in diziizle_mov:
                if len(code) > 0:
                        print ('[movshare]',diziizle_mov)
                        Mov(videoTitle,'?'+code)
                
        for code in face_1:
                if len(code) > 0:
                        print '[face]'
                xml_scanner(videoTitle,code)

        for code in divxstage:
                if len(code) > 0:
                        print ('[divxstage]',divxstage)
                        Divx(videoTitle,code)

        for code in movshare:
                if len(code) > 0:
                        print ('[movshare]',movshare)
                        Mov(videoTitle,code)
        for code in streamer:
                if len(code) > 0:
                        print '[streamer]'
                        url ='http://media2.yabancidiziizle.com/streamer.php?ticket='+code+'&&file=123.flv&start=0'
                        value.append((videoTitle,url,''))
        if vk_1:
                print '[vk] bulundu'
                for code in vk_1:
                        code=code.replace('&#038;',"&")
                        Url = 'http://vk.com/'+code
                        vk.append(Url)

        if yabanci_dizi:
                print 'YABANCI dizi'
                if videoTitle=='HQ':
                        code=HQ_COZ(yabanci_dizi)
                        for url in code:
                                value.append((videoTitle,url,''))
                
                        
        for code in youtube_1:
                unique(youtube_1)
                if len(code) > 0:
                        if code[x]==code[x+1]:
                                print 'KODLAR AYNI'
                                del code[x]
                        print '[youtube]'+str(code)
                        x+=1
                        playList.clear()
                        isim='Youtube  '+str(x)
                        Url='plugin://plugin.video.youtube/?action=play_video&videoid=' + str(code)
                        value.append((str(isim),Url,''))
        i=1
        if full_2:
                print 'full 2',full_2
                try:
                        findings=fullfilm_gizli_player(full_2[0])
                        findings=youtube_single(findings)
                        value.append((videoTitle+' '+name[i],findings,''))
                        print 'value',value
                        i+=1
                except:
                        pass

                
        for code in music:
                if len(code) > 0:
                        print '[music]'
                url = 'http://player.iyimix.com/playlist/' + code+ '.xml'
                xml_scanner(videoTitle,url)
        
        if len(lowres) > 0:
                dil=re.compile('dil=(.*?);').findall(link)
                print dil,'**************** dil ************'
                dialog = xbmcgui.Dialog()
                ret = dialog.select(__language__(30008), [__language__(30045), __language__(30046)])
                if ret == 0:
                        for code in lowres:
                                url="http://www.dizimag.com/_list.asp?dil="+str(dil[0])+"&x=%ss&d.xml"%(code)
                                print url
                                xml_scanner(videoTitle,url) 
                if ret == 1:
                        for code in highres:
                                url="http://www.dizimag.com/_list.asp?dil="+str(dil[0])+"&x=%ss&d.xml"%(code)
                                print url
                                xml_scanner(videoTitle,url) 
        else:
                pass



        
                

                
        if vk:
                print 'VK ILK OKUMA:',vk
                vk_list=prepare_page_list('',vk)
                vk_sonuc=first_vk(vk_list)
                try:
                        videoTitle=videoTitle
                except:
                        pass
                for server,url in vk_sonuc:
                        value.append((videoTitle,url,''))
                        
        print 'FINAL RESULT: ',value
        for videoTitle,url,thumbnail in value:
                xbmctools.addVideoLink(videoTitle,url,thumbnail)
                playList.add(url)
        xbmcPlayer.play(playList)

def HQ_COZ(data):
        liste=[]
        dialog = xbmcgui.Dialog()
        ret = dialog.select(__language__(30008),['Dusuk Kalite >200kb/s','Orta Kalite >500 kb/sn'])
        if ret == 0:
                        x=1
                        for i in range(3,len(data)):
                                tup=tuple(data)
                                liste.append(tup[i])
                                x+=1
##                                xbmctools.addVideoLink(videoTitle+' Part '+str(x),tup[i],'')
##                                playList.add(tup[i])
                                
                

        if ret == 1:
                        for i in range(3):
                                tup=tuple(data)
                                liste.append(tup[i])
##                                xbmctools.addVideoLink(videoTitle+' Part '+str(i),tup[i],'')
##                                playList.add(tup[i])
        return liste
