﻿import urllib,urllib2,re,xbmcplugin,xbmcgui,xbmcaddon
from BeautifulSoup import BeautifulSoup as BS
# -*- coding: cp1254 -*-
__settings__ = xbmcaddon.Addon(id='plugin.video.hdseyir')
__language__ = __settings__.getLocalizedString

import scraper,xbmctools

def CATEGORIES():
        addDir('>- Film & Dizi ARA --Tum eklentiler ve daha fazlası -- www.xbmcTR.com--Sitemizi Ziyaret Edin& Addons Rehberi Hizmete girmistir Herkez Artik Addons Yapabilir !','Search',6,'special://home/addons/plugin.video.hdseyir/resources/images/search.png')
        addDir('>- Diziler - Son Bolumlere Gore sirala ','http://www.diziizle.net/index.php?kategori=Dizi&sirala=Yeni',1,'special://home/addons/plugin.video.hdseyir/resources/images/yeni.png')
        addDir('>- Dizileri A-Z Sirala -','http://www.diziizle.net/index.php?kategori=Dizi&sirala=Ad',8,'special://home/addons/plugin.video.hdseyir/resources/images/yeni.png')
        addDir('>- Sinemalar','http://www.diziizle.net/index.php?kategori=Sinema',3,'special://home/addons/plugin.video.hdseyir/resources/images/yeni.png')
        addDir('>- Belgeseller','http://www.diziizle.net/index.php?kategori=Belgesel',3,'special://home/addons/plugin.video.hdseyir/resources/images/yeni.png')
        

def ALL(url):#kategoriler ayristirildi OK 
        link=xbmctools.get_url(url)
        
        match=re.compile('&bull; \r\n      <a href="(.*?)">(.*?)</a>').findall(link)        
        for url,name in match:
                addDir('>-' + name,'http://www.diziizle.net/'+url,1,'')

def SESSION(url):#kategoriler ayristirildi OK 
        link=xbmctools.get_url(url)
        
        match=re.compile('<img src="(.*?)" width="100" height="75" border="0"></a></div>\r\n                        <div class="ad"><a href="(.*?)">(.*?)</a></div>\r\n').findall(link)
		
        
        for a,b,c in match:
                d='http://www.diziizle.net/'
                name=c
                thumbnail=d+a
                url=d+b
                addDir(name,url,"scraper.prepare_link(name,url)",thumbnail)
                       		
def Search():
        keyboard = xbmc.Keyboard("", 'Search', False)
        keyboard.doModal()
        if keyboard.isConfirmed():
            query = keyboard.getText()
            url = ('http://www.diziizle.net/index.php?ara='+ query +'&aratur=Tumu&if.x=0&if.y=0#sonuclar')
            RECENT(url)
            
def RECENT(url):#anasayfa en yeniler OK 
        link=xbmctools.get_url(url)
        soup = BS(link)

        i=0
        for div in soup.findAll('div',  {"class": "ad"},smartQuotesTo=None):
                name= div.find('a').contents
        for div in soup.findAll('div',  {"class": "resim"},smartQuotesTo=None):
                url= div.find('a')['href']
                thumbnail= div.find('img')['src']
        for x in range(len(name)):
                addDir(name[i],url[i],7,thumbnail[i])

        soup = BS(link)
        panel = soup.findAll("td", {"id": "sayfalar"},smartQuotesTo=None)
        for a in panel[0].findAll('a'):
                print 'pass'
        url='http://www.diziizle.net/'+a['href']
        print 'URL:',url
        addDir('Sonraki Sayfa',url,1,'')
                

        MAINMENU(url)
        





def LINKLER(url):		
        link=xbmctools.get_url(url)

        server_name=["vk","movshare","Youtube","Dailymotion"]
        you_match=re.compile('<a href="(.*?)" title="Video Kaynagi"><img src="(.*?)"').findall(link)        
        for url,img in you_match:
                if img=="resimler/player_3.gif":
                        name=server_name[2]
                elif img=="resimler/player_29.gif":
                        name=server_name[0]
                elif img=="resimler/player_5.gif":
                        name=server_name[3]
                elif img=="resimler/player_16.gif":
                        name=server_name[1]
                else:
                        name='Flash server'
                addDir(name,'http://www.diziizle.net/'+url,16,'http://www.diziizle.net/'+img )

def wm(url):
                xbmcPlayer = xbmc.Player()
                playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
                playList.clear()

                link=xbmctools.get_url(url)

                                
                you_match=re.compile('player=1&link=(.*?).wmv\'').findall(link)
                print you_match
                for code in you_match:
                        print code
                        
                        addLink(name,code+'.wmv','')
                        playList.add(code)

                
                xbmcPlayer.play(playList)

def MAINMENU(url):
        addDir(__language__(30002),'http://www.yenifilmler-izle.com/','','special://home/addons/plugin.video.hdseyir/resources/images/main.jpg')
        
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param




def addLink(name,url,iconimage):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
        xbmc.Player().play(liz)
        return ok


def addDir(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
        
              
params=get_params()
url=None
name=None
mode=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)

if mode==None or url==None or len(url)<1:
        print ""
        CATEGORIES()
elif mode==1:
        print ""+url
        RECENT(url)
elif mode==3:
        print ""+url
        SESSION(url)
elif mode==4:
        print ""+url
        yt(url)
elif mode==5:
        print ""+url
        FILMOYNAT(url)
elif mode==6:
        print ""+url
        Search()
elif mode==7:
        print ""+url
        LINKLER(url)
elif mode==8:
        print ""+url
        ALL(url)
elif mode==9:
        print ""+url
        ALL2(url)
elif mode==10:
        print ""+url
        VIDEOLINKS2(url)
elif mode==11:
        print ""+url
        ytpart(url)
elif mode==12:
        print ""+url
        dm(url)
elif mode==13:
        print ""+url
        vk(url)
elif mode==14:
        print ""+url
        mv(url)
elif mode==15:
        print ""+url
        wm(url)
elif mode==16:
        scraper.prepare_list(name,url)
        
xbmcplugin.endOfDirectory(int(sys.argv[1]))
